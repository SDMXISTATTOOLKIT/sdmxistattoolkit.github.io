[
  {
    "identifier": 0,
    "geometry": "POINT(37 40)",
    "row": [
      {
        "label": "LATITUDINE",
        "value": "40.0"
      },
      {
        "label": "LONGITUDINE",
        "value": "37.0"
      },
      {
        "label": "GENERICA",
        "value": "generica4"
      }
    ]
  },
  {
    "identifier": 1,
    "geometry": "POINT(38 40)",
    "row": [
      {
        "label": "LATITUDINE",
        "value": "40.0"
      },
      {
        "label": "LONGITUDINE",
        "value": "38.0"
      },
      {
        "label": "GENERICA",
        "value": "generica3"
      }
    ]
  },
  {
    "identifier": 2,
    "geometry": "POINT(39 40)",
    "row": [
      {
        "label": "LATITUDINE",
        "value": "40.0"
      },
      {
        "label": "LONGITUDINE",
        "value": "39.0"
      },
      {
        "label": "GENERICA",
        "value": "generica2"
      }
    ]
  },
  {
    "identifier": 3,
    "geometry": "POINT(40 40)",
    "row": [
      {
        "label": "LATITUDINE",
        "value": "40.0"
      },
      {
        "label": "LONGITUDINE",
        "value": "40.0"
      },
      {
        "label": "GENERICA",
        "value": "generica1"
      }
    ]
  }
]