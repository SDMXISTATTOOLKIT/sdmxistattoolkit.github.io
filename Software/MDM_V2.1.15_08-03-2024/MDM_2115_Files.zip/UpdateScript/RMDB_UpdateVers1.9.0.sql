﻿DROP TRIGGER [Trigger_MetadataAttribute_after]
GO

DROP TRIGGER [Trigger_MetadataSet]
GO

CREATE TRIGGER [Trigger_MetadataAttribute_after]
    ON MetadataAttribute
    AFTER DELETE
    AS
    BEGIN
        SET NoCount ON
		Delete FROM AnnotationsGroup  WHERE AnnotationsGroup.Id IN (SELECT AnnotationsId FROM deleted);
		Delete FROM TranslatableItems  WHERE TranslatableItems.Id IN (SELECT ValueId FROM deleted);
    END
GO
ALTER TABLE MetadataAttribute ENABLE TRIGGER [Trigger_MetadataAttribute_after]
GO
/****** Object:  Trigger Trigger_MetadataAttribute_before    Script Date: 08/02/2019 12:05:43 ******/

CREATE TRIGGER [Trigger_MetadataSet]
    ON MetadataSet
    AFTER DELETE
    AS
    BEGIN
        SET NoCount ON
		Delete FROM AnnotationsGroup  WHERE AnnotationsGroup.Id IN (SELECT AnnotationsId FROM deleted);
		Delete FROM TranslatableItems  WHERE TranslatableItems.Id IN (SELECT NameId FROM deleted);
    END
GO
ALTER TABLE MetadataSet ENABLE TRIGGER [Trigger_MetadataSet]
GO


DELETE FROM Settings WHERE RKey = 'RM_DB_VERSION';
go
INSERT Settings (RKey, RValue) VALUES (N'RM_DB_VERSION', N'1.5');
go