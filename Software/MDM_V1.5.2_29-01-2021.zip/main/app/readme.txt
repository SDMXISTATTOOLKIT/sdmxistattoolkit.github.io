- version 1.5.1 or later - for updating the enviroment from a software version previous to 1.5.1 the following steps must be done:
	1) execute the following query in the AUTHDB: 
		DELETE FROM AUTH_DB_CONNECTION;
		DELETE FROM AUTH_CONNECTION_STRING;

	2) save the node from the Node - Configuration page