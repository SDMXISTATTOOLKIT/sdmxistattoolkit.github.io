CREATE TABLE "ComponentMappingAlias" ( 
	"IDComponentAlias" int identity not null,
	"IDMapping" int not null,
	"ColumnName" nvarchar(255) not null,
	"ColumnAlias" nvarchar(255) not null) ON 'PRIMARY'  
GO

ALTER TABLE "ComponentMappingAlias"
	ADD CONSTRAINT "PK_ComponentMappingAlias" primary key nonclustered ("IDComponentAlias")   
GO