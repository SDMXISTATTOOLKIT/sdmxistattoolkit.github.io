ALTER TABLE ComponentMapping ADD FieldExpression nvarchar(max) Null
GO