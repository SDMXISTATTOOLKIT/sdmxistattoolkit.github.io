
ALTER FUNCTION [dbo].[Right_Trim] (@input_string varchar(MAX), @str nvarchar(max))
RETURNS VARCHAR(MAX)
begin

DECLARE @init INT;
SET @init = len(@input_string) - len(@str) + 1;

if len(@str) = 0
   set @input_string = RTRIM(@input_string)
else
begin
   WHILE (substring(@input_string, @init, len(@str)) = @str)
     SET @init = @init - len(@str);
end

return substring(@input_string, 1, @init + len(@str) - 1);
END
GO

ALTER FUNCTION [dbo].[Left_Trim] (@input_string nvarchar(MAX), @str nvarchar(MAX))
RETURNS NVARCHAR(MAX)
begin

DECLARE @MyCounter INT;
SET @MyCounter = 1;

IF len(@str) = 0
  SET @input_string = LTRIM(@input_string);
else
begin
  WHILE NOT (substring(@input_string, @MyCounter, len(@str)) <> @str)
    SET @MyCounter = @MyCounter + len(@str);
end

return substring(@input_string, @MyCounter,len (@input_string) - @MyCounter+1);
END
GO