ALTER TABLE Mapping ADD ProcessFilePath nvarchar(MAX) COLLATE Latin1_General_CI_AS NULL
GO

ALTER TABLE Mapping ADD PluginId varchar(255) NULL
GO

ALTER TABLE Mapping ADD IconName varchar(100) NULL
GO

ALTER TABLE Mapping ADD IconColor varchar(100) NULL
GO

ALTER TABLE Mapping ADD SequenceMapping bit DEFAULT 0 NOT NULL
GO

ALTER TABLE SequenceMapping ADD IconName varchar(20), IconColor varchar(20)
GO
