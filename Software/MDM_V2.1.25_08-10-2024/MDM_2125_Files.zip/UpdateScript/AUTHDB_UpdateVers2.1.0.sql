INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME,PARENT_FUNCT_ID) VALUES('mapping-handler',null);
INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME,PARENT_FUNCT_ID) VALUES('create-ddb-connection',null);
INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME,PARENT_FUNCT_ID) VALUES('create-dataset',null);
INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME,PARENT_FUNCT_ID) VALUES('create-mapping-set',null);
INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME,PARENT_FUNCT_ID) VALUES('dataflow-publishing',null);

UPDATE [AUTH_FUNCTIONALITY]
SET PARENT_FUNCT_ID = q.FUNCT_ID
FROM(	SELECT FUNCT_ID
		FROM [AUTH_FUNCTIONALITY]
		WHERE FUNCT_NAME = 'mapping-handler')q
WHERE FUNCT_NAME IN
('create-ddb-connection','create-dataset','create-mapping-set','dataflow-publishing');



/* Create new table "AUTH_USER_DDB_CONNECTION".                                                      */
/* "AUTH_USER_DDB_CONNECTION" : Tabella deputata a contenere l�associazione tra connessione e utente */
/* 	"USER_ID" : Id dell'utente                                                                       */
/* 	"UNIQUE_CONNECTION_NAME" : Nome della connessione                                                */

CREATE TABLE [dbo].[AUTH_USER_DDB_CONNECTION](
	[USER_ID] [bigint] NOT NULL,
	[UNIQUE_CONNECTION_NAME] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_AUTH_USER_DDB_CONNECTION] PRIMARY KEY CLUSTERED
(
	[USER_ID] ASC,
	[UNIQUE_CONNECTION_NAME] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/* Add foreign key constraints to table "AUTH_USER_DDB_CONNECTION".        */

ALTER TABLE [dbo].[AUTH_USER_DDB_CONNECTION]  WITH CHECK ADD  CONSTRAINT [SRI_USER_AUTH_USER_DDB_CONNECTION_FK1] FOREIGN KEY([USER_ID])
REFERENCES [dbo].[SRI_USER] ([ID])
GO

ALTER TABLE [dbo].[AUTH_USER_DDB_CONNECTION] CHECK CONSTRAINT [SRI_USER_AUTH_USER_DDB_CONNECTION_FK1]
GO

-- Task 1282 import sdmx 2.0, creazione voce pagina

INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME, PARENT_FUNCT_ID) VALUES('import-structures-20', NULL);

UPDATE [AUTH_FUNCTIONALITY]
SET PARENT_FUNCT_ID = q.FUNCT_ID
FROM(	SELECT FUNCT_ID
		FROM [AUTH_FUNCTIONALITY]
		WHERE FUNCT_NAME = 'utilities')q
WHERE FUNCT_NAME IN ('import-structures-20')