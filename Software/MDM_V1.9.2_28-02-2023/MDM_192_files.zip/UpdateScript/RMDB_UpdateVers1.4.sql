﻿ALTER TABLE Annotation ALTER COLUMN [AnnotationTypeId] [int] NULL;
go
DELETE FROM Settings WHERE RKey = 'RM_DB_VERSION';
go
INSERT Settings (RKey, RValue) VALUES (N'RM_DB_VERSION', N'1.4');
go