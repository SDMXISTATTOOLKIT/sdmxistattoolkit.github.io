/* NEW TABLES FOR SEQUENCE MAPPING */

/* Create new table "SMMapp".                                                                 */
/* "SMMapp" : Tabella di collegamento tra i Mapping e i Sequence Mapping (SM) di cui fanno parte */
/* 	"IDSeqMapping" : ID del Sequence Mapping                                                  */
/* 	"IDMapping" : ID del Mapping                                                              */  
/* 	"Order" : ordine del Mapping nel Sequnce Mapping                                        */  
create table "SMMapp" ( 
	"IDSeqMapping" int not null,
	"IDMapping" int not null,
	"Order" int null)  

go

alter table "SMMapp"
	add constraint "SMMapp_PK" primary key ("IDSeqMapping", "IDMapping")   


go

/* Create new table "SequenceMapping".                                                        */
/* "SequenceMapping" : Tabella dei Sequence Mapping, ovvero raggruppamenti di Mapping         */
/* 	"IDSeqMapping" : IDSeqMapping identifies SequenceMapping                                  */
/* 	"IDCube" : ID del cubo a cui il Sequence Mapping si riferisce                             */
/* 	"TimeStmp" : TimeStmp di generazione del Sequence Mapping                                 */
/* 	"Name" : Nome del Sequence Mapping                                                        */
/* 	"Description" : Descrizione del SequenceMapping                                           */  
create table "SequenceMapping" ( 
	"IDSeqMapping" int identity not null,
	"IDCube" int not null,
	"TimeStmp" datetime not null,
	"Name" nvarchar(255) not null,
	"Description" nvarchar(2000) null)  

go

alter table "SequenceMapping"
	add constraint "SequenceMapping_PK" primary key ("IDSeqMapping")   


go

/* Add the remaining keys, constraints and indexes for the table "SequenceMapping".           */
alter table "SequenceMapping" add constraint "UQ_Mapping" unique (
	"Name")  


go

/* Add foreign key constraints to table "SMMapp".                                             */
alter table "SMMapp"
	add constraint "SequenceMapping_SMMapp_FK1" foreign key (
		"IDSeqMapping")
	 references "SequenceMapping" (
		"IDSeqMapping") on update no action on delete cascade  

go

alter table "SMMapp"
	add constraint "Mapping_SMMapp_FK1" foreign key (
		"IDMapping")
	 references "Mapping" (
		"IDMapping") on update no action on delete no action  

go


/* UPDATE FOR LASTUPDATERECORD IN DATAFLOWS --- TICKET ISTAT-779 */


/* Adding LastUpdateRecord field to CatDataflow table */
ALTER TABLE CatDataFlow
ADD LastUpdateRecord datetime null
GO

UPDATE df 
SET df.LastUpdateRecord = c.LastUpdated
FROM CatDataflow df
INNER JOIN CatCube c on df.IDCube = c.IDCube
WHERE df.LastUpdateRecord is NULL

/* Updating cubes' ViewCurrentData views */

declare @cmd varchar(8000)
declare cmds cursor for 
select REPLACE(REPLACE(definition, 'FROM Filt', ', FA.InsertDate' + CHAR(13) + 'FROM Filt'), 'CREATE VIEW ', 'ALTER VIEW ')
from sys.objects     o
join sys.sql_modules m on m.object_id = o.object_id
where o.type = 'V' and name like 'Dataset_[^D]%_ViewCurrentData' and definition not like '%InsertDate%'

open cmds
while 1=1
begin
    fetch cmds into @cmd
    if @@fetch_status != 0 break
    exec(@cmd)
end
close cmds;
deallocate cmds

/* Updating dataflows' ViewCurrentData views */

--deleting views with wrong references
declare cmds cursor for 
select 'drop view Dataset_DF' + SUBSTRING(name, CHARINDEX('_DF', o.name) + 3, LEN(o.name) - LEN('Dataset_DF_ViewCurrentData')) + '_ViewCurrentData'
from sys.objects     o
join sys.sql_modules m on m.object_id = o.object_id
LEFT JOIN CatDataflow df on df.IDDataFlow = SUBSTRING(name, CHARINDEX('_DF', o.name) + 3, LEN(o.name) - LEN('Dataset_DF_ViewCurrentData')) --getting df id from the view name
where o.type = 'V' and name like 'Dataset_DF%_ViewCurrentData' and df.IDDataFlow is NULL

open cmds
while 1=1
begin
    fetch cmds into @cmd
    if @@fetch_status != 0 break
    exec(@cmd)
end
close cmds;
deallocate cmds

--updating other views

declare cmds cursor for 
select REPLACE(REPLACE(definition, ' FROM Dataset', ',InsertDate FROM Dataset'), 'CREATE VIEW ', 'ALTER VIEW ')
from sys.objects     o
join sys.sql_modules m on m.object_id = o.object_id
where o.type = 'V' and name like 'Dataset_DF%_ViewCurrentData' and definition not like '%InsertDate%'

open cmds
while 1=1
begin
    fetch cmds into @cmd
    if @@fetch_status != 0 break
    exec(@cmd)
end
close cmds;
deallocate cmds

/* Database version */
update DDB_VERSION SET MINOR = 5, UPGRADE_STAMP = getdate()
GO