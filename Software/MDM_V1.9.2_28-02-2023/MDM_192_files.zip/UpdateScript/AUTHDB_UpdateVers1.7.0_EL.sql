INSERT INTO [AUTH_FUNCTIONALITY] VALUES
('easy-loading', NULL),
('easy-loading-create', NULL),
('easy-loading-update', NULL)

UPDATE [AUTH_FUNCTIONALITY]
SET PARENT_FUNCT_ID = q.FUNCT_ID
FROM(	SELECT FUNCT_ID
		FROM [AUTH_FUNCTIONALITY]
		WHERE FUNCT_NAME = 'easy-loading')q
WHERE FUNCT_NAME IN ('easy-loading-create','easy-loading-update')

/* Create new table "AUTH_USER_EXTERNAL".                                                     */
/* "AUTH_USER_EXTERNAL" : Tabella per la gestione dei login di utenti tramite provider esterni */
/* 	"LOGIN_PROVIDER" : Chiave di login sul provider esterno (normalmente la mail dell'utente) */
/* 	"PROVIDER_KEY" : Chiave identificativa del provider (e.g. shibboleth, google, facebook, etc.) */
/* 	"USER_ID" : Id dell'utente a cui il login si riferisce                                    */  
create table "AUTH_USER_EXTERNAL" ( 
	"LOGIN_PROVIDER" varchar(255) not null,
	"PROVIDER_KEY" varchar(50) not null,
	"USER_ID" bigint not null)  

go

alter table "AUTH_USER_EXTERNAL"
	add constraint "AUTH_USER_EXTERNAL_PK" primary key ("LOGIN_PROVIDER", "PROVIDER_KEY")   


go

/* Add foreign key constraints to table "AUTH_USER_EXTERNAL".                                 */
alter table "AUTH_USER_EXTERNAL"
	add constraint "SRI_USER_AUTH_USER_EXTERNAL_FK1" foreign key (
		"USER_ID")
	 references "SRI_USER" (
		"ID") on update no action on delete cascade  

go