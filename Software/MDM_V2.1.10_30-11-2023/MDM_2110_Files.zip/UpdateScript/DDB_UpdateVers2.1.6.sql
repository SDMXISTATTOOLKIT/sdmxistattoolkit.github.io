ALTER TABLE CatCube Add HasBackup bit Not Null default 0
GO

CREATE FUNCTION [dbo].[Right_Trim] (@input_string varchar(MAX), @str nvarchar(max))
RETURNS VARCHAR(MAX)
begin
DECLARE @init INT;
SET @init = len(@input_string) - len(@str) + 1;

WHILE (substring(@input_string, @init, len(@str)) = @str)
   SET @init = @init - len(@str);

return substring(@input_string, 1, @init + len(@str) - 1);
END
GO

CREATE FUNCTION [dbo].[Left_Trim] (@input_string nvarchar(MAX), @str nvarchar(MAX))
RETURNS NVARCHAR(MAX)
begin

DECLARE @MyCounter INT;
SET @MyCounter = 1;

WHILE NOT (substring(@input_string, @MyCounter, len(@str)) <> @str)
   SET @MyCounter = @MyCounter + len(@str);

return substring(@input_string, @MyCounter,len (@input_string) - @MyCounter+1);
END
GO
