INSERT INTO [AUTH_FUNCTIONALITY] VALUES
('update-databrowser-dsd-cache', NULL)

UPDATE [AUTH_FUNCTIONALITY]
SET PARENT_FUNCT_ID = q.FUNCT_ID
FROM(	SELECT FUNCT_ID
		FROM [AUTH_FUNCTIONALITY]
		WHERE FUNCT_NAME = 'data-manager')q
WHERE FUNCT_NAME IN ('update-databrowser-dsd-cache')

/* Create new table "AUTH_CAT_SCH".                                                           */
/* "AUTH_CAT_SCH" : Tabella contenente i category scheme per la categorizzazione              */
/* 	"CAT_SCH_ID" : Id del category scheme                                                     */
/* 	"ID_MSDB" : Identificativo del category scheme nel MSDB nel formadi id+agency+version (es. ISTAT_DW+IT1+1.0)         */  
create table "AUTH_CAT_SCH" ( 
	"CAT_SCH_ID" int identity not null,
	"ID_MSDB" varchar(150) not null)  

go

alter table "AUTH_CAT_SCH"
	add constraint "AUTH_CAT_SCH_PK" primary key ("CAT_SCH_ID")   


go


/* Create new table "AUTH_USER_CAT_SCH".                                                      */
/* "AUTH_USER_CAT_SCH" : Tabella che mette in relazione un utente con i category scheme su cui ha diritto di categorizzazione */
/* 	"USER_ID" : Id dell'utente                                                                */
/* 	"CAT_SCH_ID" : Id del category scheme                                                     */  
create table "AUTH_USER_CAT_SCH" ( 
	"USER_ID" bigint not null,
	"CAT_SCH_ID" int not null)  

go

alter table "AUTH_USER_CAT_SCH"
	add constraint "AUTH_USER_CAT_SCH_PK" primary key ("USER_ID", "CAT_SCH_ID")   


go


/* Add foreign key constraints to table "AUTH_USER_CAT_SCH".                                  */
alter table "AUTH_USER_CAT_SCH"
	add constraint "SRI_USER_AUTH_USER_CAT_SCH_FK1" foreign key (
		"USER_ID")
	 references "SRI_USER" (
		"ID") on update no action on delete cascade  

go

alter table "AUTH_USER_CAT_SCH"
	add constraint "AUTH_CAT_SCH_AUTH_USER_CAT_SCH_FK1" foreign key (
		"CAT_SCH_ID")
	 references "AUTH_CAT_SCH" (
		"CAT_SCH_ID") on update no action on delete no action  

go

INSERT INTO AUTH_FUNCTIONALITY (FUNCT_NAME, PARENT_FUNCT_ID) VALUES(N'plugins', NULL);


UPDATE [AUTH_FUNCTIONALITY]
SET PARENT_FUNCT_ID = q.FUNCT_ID
FROM(	SELECT FUNCT_ID
		FROM [AUTH_FUNCTIONALITY]
		WHERE FUNCT_NAME = 'utilities')q
WHERE FUNCT_NAME IN ('plugins')

